# fanuc_lrmate200i_moveit_plugins

## Overview

This package is part of the [ROS-Industrial][] program. See the main
[fanuc][] page on the ROS wiki for more information on usage.

## Contents

See `package.xml` for information about the contents of this package.


[ROS-Industrial]: http://wiki.ros.org/Industrial
[fanuc]: http://wiki.ros.org/fanuc
