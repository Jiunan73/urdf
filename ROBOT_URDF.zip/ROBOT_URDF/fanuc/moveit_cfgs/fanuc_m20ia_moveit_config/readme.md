# fanuc_m20ia_moveit_config

## Overview

This package is part of the [ROS-Industrial][] program. See the main [fanuc][]
page on the ROS wiki for more information on usage.

## Contents

See `package.xml` for information about the contents of this package.

## Known issues

Please see the [known issues][] page on the ROS wiki.



[ROS-Industrial]: http://wiki.ros.org/Industrial
[fanuc]: http://wiki.ros.org/fanuc
[known issues]: http://wiki.ros.org/fanuc/indigo/known_issues
