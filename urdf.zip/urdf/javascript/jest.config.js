export default {
    'transformIgnorePatterns': [],
};
